package com.vsfhs.security;

import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🚀 Enable Chrome DevTools remote inspection for the Capacitor WebView
        WebView.setWebContentsDebuggingEnabled(true);
    }
}
